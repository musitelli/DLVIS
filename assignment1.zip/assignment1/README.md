Details about this assignment can be found [on the course webpage](https://eva.fing.edu.uy/mod/assign/view.php?id=194303).
